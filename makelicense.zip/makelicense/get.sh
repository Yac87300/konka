
echo "SPUID `./sli -tt getbind`"
